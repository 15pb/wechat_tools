// MyDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MFCGameDLL.h"
#include "MyDlg.h"
#include "afxdialogex.h"


// CMyDlg �Ի���

IMPLEMENT_DYNAMIC(CMyDlg, CDialogEx)

CMyDlg::CMyDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG1, pParent)
{

}

CMyDlg::~CMyDlg()
{
}

void CMyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMyDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CMyDlg::OnBnClickedButton1)
END_MESSAGE_MAP()


// CMyDlg ��Ϣ��������
struct WXString {
	int num;
	wchar_t* pString;
	int nLen;
	int nMaxLen;
	int n1;
	int n2;
	int n3;
	int n4;

	WXString(wchar_t* pStr) {
		int len = wcslen(pStr);
		pString = new wchar_t[len + 1];
		memset(pString, 0, len * 2 + 2);
		memcpy(pString, pStr, len * 2);
		nLen = len;
		nMaxLen = len + 2;
		n1 = 0;
		n2 = 0;
		n3 = 0;
		n4 = 0;
	}

	~WXString() {
		if (pString)
			delete pString;
	}
};
#include "MFCGameDLL.h"
void CMyDlg::OnBnClickedButton1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	HMODULE hMod = ::GetModuleHandle(L"wechatwin.dll");
	DWORD dwAddr = (DWORD)hMod + 0x2110C0;

	WXString szUser(L"filehelper");
	WXString szContent(L"hello 15pb");
	char* pAddr = (char*)&szContent + 0x14;
	char* pUser = (char*)&szUser.pString;
	char* pPass = (char*)&szContent.pString;

	char buf[0x3d4] = { 0 };
	_asm {
		push 1
		push 0
		push pPass
		push pUser

		lea eax, buf
		push eax
		mov eax, dwAddr
		call eax
	}
}
