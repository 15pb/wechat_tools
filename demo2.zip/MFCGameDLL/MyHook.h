#pragma once
class CMyHook
{
public:
	CMyHook();
	~CMyHook();


	byte m_oldData[5];


	int static HookStart(byte* pHookAddr, byte* pNewAddr);

	int static HookStop(byte* pHookAddr, byte* pNewAddr);

};

