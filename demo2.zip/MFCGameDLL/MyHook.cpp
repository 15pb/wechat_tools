#include "stdafx.h"
#include "MyHook.h"


CMyHook::CMyHook()
{
}


CMyHook::~CMyHook()
{
}


//int CMyHook::HookStart(byte* pHookAddr, byte* pNewAddr, byte* pWriteData)
//{
//	//::VirtualProtect(pHookAddr, pNewAddr, );
//
//
//	//::VirtualProtect();
//
//
//	return 0;
//}
//
//
//int CMyHook::HookStop(byte* pHookAddr, byte* pNewAddr, byte* pWriteData)
//{
//	return 0;
//}
